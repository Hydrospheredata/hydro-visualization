import random
import hydro_serving_grpc as hs
import numpy as np
def predict(**kwargs):
    imgs = np.array(kwargs['features'].float_val, dtype='float').reshape((-1, 1792))
    embs = np.concatenate([np.random.random(1, 100) for i in range(len(imgs))])
    embs_proto = hs.TensorProto(
        double_val=embs.flatten,
        dtype=hs.DT_DOUBLE,
        tensor_shape=hs.TensorShapeProto(dim=[hs.TensorShapeProto.Dim(embs.shape[0]), hs.TensorShapeProto.Dim(embs.shape[1])]))

    return hs.PredictResponse(outputs={"embeddings": embs_proto})